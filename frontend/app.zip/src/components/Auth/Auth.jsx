import React, { useState } from "react";
import { Particles } from "react-tsparticles";
import { loadFull } from "tsparticles";
import particlesConfig from "../../styles/particlesConfig";
import LoginForm from "./LoginForm";
import RegisterForm from "./RegisterForm";
import RecoverForm from "./RecoverForm";

const Auth = () => {
    const [activeForm, setActiveForm] = useState("login");

    const particlesInit = async (engine) => {
        await loadFull(engine);
    };

    const particlesLoaded = (container) => {
        console.log("Particles loaded", container);
    };

    return (
        <div className="relative flex items-center justify-center min-h-screen bg-gray-900 text-white px-4 lg:px-0 overflow-hidden">
            {/* Fondo de partículas */}
            <Particles
                id="tsparticles"
                init={particlesInit}
                options={{
                    ...particlesConfig,
                    fullScreen: {
                        enable: true,
                        zIndex: 0,
                    },
                }}
                className="absolute inset-0"
            />

            {/* Tarjeta principal */}
            <div className="w-full max-w-md lg:max-w-lg bg-gray-800/80 backdrop-blur-sm rounded-2xl shadow-lg p-6 sm:p-8 transform transition duration-500 hover:scale-105">
                {activeForm === "login" && <LoginForm />}
                {activeForm === "register" && <RegisterForm />}
                {activeForm === "recover" && <RecoverForm />}

                {/* Enlaces de navegación */}
                <div className="mt-6 text-center text-sm text-gray-400 space-y-2">
                    {activeForm === "login" && (
                        <>
                            <p>
                                ¿No tienes una cuenta?{" "}
                                <button
                                    className="text-gray-300 hover:text-gray-100 transition-all duration-300"
                                    onClick={() => setActiveForm("register")}
                                >
                                    Crear cuenta
                                </button>
                            </p>
                            <p>
                                ¿Olvidaste tu contraseña?{" "}
                                <button
                                    className="text-gray-300 hover:text-gray-100 transition-all duration-300"
                                    onClick={() => setActiveForm("recover")}
                                >
                                    Recuperar contraseña
                                </button>
                            </p>
                        </>
                    )}
                    {(activeForm === "register" || activeForm === "recover") && (
                        <p>
                            ¿Ya tienes una cuenta?{" "}
                            <button
                                className="text-gray-300 hover:text-gray-100 transition-all duration-300"
                                onClick={() => setActiveForm("login")}
                            >
                                Iniciar sesión
                            </button>
                        </p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Auth;
