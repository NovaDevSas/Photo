import React from "react";
import Auth from "./components/Auth/Auth"; // Ajusta la ruta si es diferente

const App = () => {
    return <Auth />;
};

export default App;
